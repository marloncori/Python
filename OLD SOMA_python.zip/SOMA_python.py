import numpy as np

#SOMA parameters
prt = 0.2
path_lenght = 2
step = 0.11
migrations = 200
pop_size = 30

#general parameters
dimension = 3
min_s = [-500, -500, -500]
max_s = [500, 500, 500]

class Individual:
    """Individual of the population. It holds parameters of the solution as well as the fitness of the solution."""
    def __init__(self, params, fitness):
        self.params = params
        self.fitness = fitness

    def __repr__(self):
        return '{} fitness: {}'.format(self.params, self.fitness)

#benchmark cost functions
def de_jong_first(params):
    return np.sum(np.square(params))

def rastrigin(params):
    return 10 * len(params) + np.sum(np.square(params) - 10 * np.cos(2 * np.pi * params))

def schwefel(params):
    return 418.9829 * len(params) - np.sum(params * np.sin(np.sqrt(np.abs(params))))

def evaluate(params):
    """Returns fitness of the params"""
    #return de_jong_first(params)
    return schwefel(params)    
    #return rastrigin(params)

def bounded(params, min_s: list, max_s: list):
    """
    Returns bounded version of params
    All params that are outside of bounds (min_s, max_s) are reassigned by a random number within bounds
    """
    return np.array([np.random.uniform(min_s[d], max_s[d])
            if params[d] < min_s[d] or params[d] > max_s[d] 
            else params[d] 
            for d in range(len(params))])

def generate_population(size, min_s, max_s, dimension):
    def generate_individual():
        params = np.random.uniform(min_s, max_s, dimension)
        fitness = evaluate(params)
        return Individual(params, fitness)
    return [generate_individual() for _ in range(size)]

def generate_prt_vector(prt, dimension):
    return np.random.choice([0, 1], dimension, p=[prt, 1-prt])

def get_leader(population):
    """Finds leader of the population by its fitness (the lower the better)."""
    return min(population, key = lambda individual: individual.fitness)

def soma_all_to_one(population, prt, path_length, step, migrations, min_s, max_s, dimension):
    for generation in range(migrations):
        leader = get_leader(population)
        for individual in population:
            if individual is leader:
                continue
            next_position = individual.params
            prt_vector = generate_prt_vector(prt, dimension)
            for t in np.arange(step, path_length, step):
                current_position = individual.params + (leader.params - individual.params) * t * prt_vector
                current_position = bounded(current_position, min_s, max_s)
                fitness = evaluate(current_position)
                if fitness <= individual.fitness:
                    next_position = current_position
                    individual.fitness = fitness
            individual.params = next_position
    return get_leader(population)

def soma_all_to_one_rand(population, prt, path_length, step, migrations, min_s, max_s, dimension):
    for generation in range(migrations):
        leading = np.random.choice(population)
        for individual in population:
            if individual is leading:
                continue
            next_position = individual.params
            prt_vector = generate_prt_vector(prt, dimension)
            for t in np.arange(step, path_length, step):
                current_position = individual.params + (leading.params - individual.params) * t * prt_vector
                current_position = bounded(current_position, min_s, max_s)
                fitness = evaluate(current_position)
                if fitness <= individual.fitness:
                    next_position = current_position
                    individual.fitness = fitness
            individual.params = next_position
    return get_leader(population)

def soma_all_to_one_adaptive(population, prt, path_length, step, migrations, min_s, max_s, dimension):
    for generation in range(migrations):
        for individual in population:
            leader = get_leader(population)
            if individual is leader:
                continue
            next_position = individual.params
            prt_vector = generate_prt_vector(prt, dimension)
            for t in np.arange(step, path_length, step):
                current_position = individual.params + (leader.params - individual.params) * t * prt_vector
                current_position = bounded(current_position, min_s, max_s)
                fitness = evaluate(current_position)
                if fitness <= individual.fitness:
                    next_position = current_position
                    individual.fitness = fitness
            individual.params = next_position
    return get_leader(population)

def soma_all_to_one_rand_adaptive(population, prt, path_length, step, migrations, min_s, max_s, dimension):
    for generation in range(migrations):
        for individual in population:
            leading = np.random.choice(population)
            if individual is leading:
                continue
            next_position = individual.params
            prt_vector = generate_prt_vector(prt, dimension)
            for t in np.arange(step, path_length, step):
                current_position = individual.params + (leading.params - individual.params) * t * prt_vector
                current_position = bounded(current_position, min_s, max_s)
                fitness = evaluate(current_position)
                if fitness <= individual.fitness:
                    next_position = current_position
                    individual.fitness = fitness
            individual.params = next_position
    return get_leader(population)

def soma_all_to_all(population, prt, path_length, step, migrations, min_s, max_s, dimension):
    for generation in range(migrations):
        for individual in population:
            next_position = individual.params
            prt_vector = generate_prt_vector(prt, dimension)
            for leading in population:
                if individual is leading:
                    continue
                for t in np.arange(step, path_length, step):
                    current_position = individual.params + (leading.params - individual.params) * t * prt_vector
                    current_position = bounded(current_position, min_s, max_s)
                    fitness = evaluate(current_position)
                    if fitness <= individual.fitness:
                        next_position = current_position
                        individual.fitness = fitness
            individual.params = next_position
    return get_leader(population)

def soma_all_to_all_adaptive(population, prt, path_length, step, migrations, min_s, max_s, dimension):
    for generation in range(migrations):
        for individual in population:
            next_position = individual.params
            prt_vector = generate_prt_vector(prt, dimension)
            for leading in population:
                if individual is leading:
                    continue
                for t in np.arange(step, path_length, step):
                    current_position = individual.params + (leading.params - individual.params) * t * prt_vector
                    current_position = bounded(current_position, min_s, max_s)
                    fitness = evaluate(current_position)
                    if fitness <= individual.fitness:
                        next_position = current_position
                        individual.fitness = fitness
                individual.params = next_position
    return get_leader(population)

population = generate_population(pop_size, min_s, max_s, dimension)
result = soma_all_to_one(population, prt, path_lenght, step, migrations, min_s, max_s, dimension)
print(result)